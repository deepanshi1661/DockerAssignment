#!/bin/bash

# Start the first process
./userService &
  
# Start the second process
./postService &

./productService &
  
# Wait for any process to exit
wait -n
  
# Exit with status of process that exited first
exit $?