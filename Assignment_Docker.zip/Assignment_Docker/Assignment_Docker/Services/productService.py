from flask import Flask
# import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('localhost', 27017)

db = client.flask_db

class Product:
    def __init__(self,id,name,expiry) -> None:
        self.id=id
        self.name=name
        self.expiry=expiry

        

@app.route('/user/all-products',method='GET')
def get_products():
    products=json.stringify(json.load(db.Table('products')))
    return products

@app.route('/user/add-product',method='POST')
def add_user(id,name,expiry):
    try:
        product = Product(id,name,expiry)
        table = db.Table('products')
        table.add(product)
        return {"user":{"id":id,"name":name,"expiry":expiry}}
    except:
        return "Invalid Product"






if __name__ == '__main__':
    app.run(port=5000,host='0.0.0.0',debug=True)