from flask import Flask
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('localhost', 27017)

db = client.flask_db

class User:
    def __init__(self,id,name,age) -> None:
        self.id=id
        self.name=name
        self.age=age

        

@app.route('/user/all-users',method='GET')
def get_users():
    users=json.stringify(json.load(db.Table('users')))
    return users

@app.route('/user/add-user',method='POST')
def add_user(id,name,age):
    try:
        user = User(id,name,age)
        table = db.Table('users')
        table.add(user)
        return {"user":{"id":id,"name":name,"age":age}}
    except:
        return "Invalid user"






if __name__ == '__main__':
    app.run(port=5000,host='0.0.0.0',debug=True)