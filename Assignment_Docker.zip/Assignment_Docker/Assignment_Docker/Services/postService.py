from flask import Flask
# import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('localhost', 27017)

db = client.flask_db

class Post:
    def __init__(self,id,name) -> None:
        self.id=id
        self.name=name
        

        

@app.route('/user/all-posts',method='GET')
def get_posts():
    posts=json.stringify(json.load(db.Table('posts')))
    return posts

@app.route('/user/add-post',method='POST')
def add_user(id,name):
    try:
        post = post(id,name)
        table = db.Table('posts')
        table.add(post)
        return {"user":{"id":id,"name":name}}
    except:
        return "Invalid post"






if __name__ == '__main__':
    app.run(port=5000,host='0.0.0.0',debug=True)